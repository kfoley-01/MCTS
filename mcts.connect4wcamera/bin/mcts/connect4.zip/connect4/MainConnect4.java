package mcts.connect4;

import java.util.Scanner;

public class MainConnect4 {
	public static void main(String [] args) throws CloneNotSupportedException
	{
	
		vsRandomStats(2);
	
		connect4 a4 = new connect4();
		//a4.gameLoopVsPlayer(2);
		
		//a4.playerVSPlayerr(1);
		
	
	}
	
	static void vsRandomStats(int turn ) {
		int win = 0;
		int loss=0;
		int draw =0;
		for ( int i =0;i<10000;i++) {
			connect4 c4 = new connect4();
			int res = c4.gameLoopVsRandom(turn);
				if(res ==1) {
					win ++;
					
					
		}
				else if(res == -1 ) {
					loss++;
					break;
					
				}
				else if (res==0) {
					draw++;
					
				}
				System.out.println("run : "+ i );
//				c4.boardToString();
		}
		System.out.println("Mcts won : "+ win+"\n Lost : "+loss+"\n Drew : "+draw);
		
	}
}
