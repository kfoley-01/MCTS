package mcts.connect4;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;

public class Window extends JPanel {
  private static final int ROWS = 7;
  private static final int COLS = 6;
  private static final int CELL_SIZE = 100;
  private static boolean valentine =false;

  private int[][] board = new int[ROWS][COLS];

  public Window() {
    JFrame frame = new JFrame("Connect 4");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(COLS * CELL_SIZE+15, (ROWS + 1) * CELL_SIZE+CELL_SIZE);
    frame.add(this);
    frame.setVisible(true);
    setBackground(Color.BLUE);
    frame.setAlwaysOnTop(true);
    frame.setLocationRelativeTo(null);

  }
  public Window(boolean valentine) {
	    JFrame frame = new JFrame("Connect 4");
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.setSize(COLS * CELL_SIZE, (ROWS + 1) * CELL_SIZE);
	    frame.add(this);
	    frame.setVisible(true);
	    this.valentine=valentine;
	   setBackground(Color.blue);
	
	  }

  @Override
  protected void paintComponent(Graphics g) {
    super.paintComponent(g);

    // Draw the game board
    for (int row = 0; row < ROWS; row++) {
      for (int col = 0; col < COLS; col++) {
        g.setColor(Color.BLUE);
        g.drawRect(col * CELL_SIZE, (row + 1) * CELL_SIZE, CELL_SIZE, CELL_SIZE);
        if (board[row][col] == 0) {
          g.setColor(Color.WHITE);
        } else if (board[row][col] == 1) {
          g.setColor(Color.RED);
        } else if (board[row][col] == 2) {
          g.setColor(Color.YELLOW);
        }
        if(!valentine) {
        g.fillOval(col * CELL_SIZE, (row + 1) * CELL_SIZE, CELL_SIZE, CELL_SIZE);
        }
        else {
        	// Draw a heart instead of an oval
            int x = col * CELL_SIZE + CELL_SIZE/4;
            int y = (row + 1) * CELL_SIZE + CELL_SIZE/4;
            int width = CELL_SIZE/2;
            int height = CELL_SIZE/2;
            int curveWidth = width / 2;
            int curveHeight = height/2;

            // Draw left curve
            g.fillArc(x, y+12, curveWidth, curveHeight, 0, 180);
            // Draw right curve
            g.fillArc(x + curveWidth, y+12, curveWidth, curveHeight, 0, 180);
            // Draw center triangle
            int[] xPoints = { x, x + width/2, x + width };
            int[] yPoints = { y + height/2, y + height, y + height/2 };
            g.fillPolygon(xPoints, yPoints, 3);
        }
      }
    }
  }
  public void setWindow(int [][] board) {
	  this.board=board;
  }
}
  